#!/usr/bin/env bash
set -xe

# build command
go build -o bin/application application.go